#!/bin/bash
spark-submit \
  --packages org.apache.hudi:hudi-spark3.4-bundle_2.12:0.14.1,org.apache.hadoop:hadoop-aws:3.3.4,com.amazonaws:aws-java-sdk-bundle:1.12.262 \
  src/consumption_recommendation.py \
  --config configs/ecomm_prod.yml
