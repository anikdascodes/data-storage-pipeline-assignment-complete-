# Ecommerce Seller Recommendation - Skeleton

This repository contains the skeleton for Assignment 1:
- ETL pipelines to clean seller_catalog, company_sales, competitor_sales
- Quarantine handling for bad data
- Consumption layer to compute recommendations

Files created:
- configs/ecomm_prod.yml (edit to set S3/local paths)
- src/etl_seller_catalog.py (skeleton)
- src/etl_company_sales.py (placeholder)
- src/etl_competitor_sales.py (placeholder)
- src/consumption_recommendation.py (placeholder)
- scripts/*.sh (spark-submit wrappers)

Next steps:
1. Populate config paths in configs/ecomm_prod.yml
2. Implement cleaning & DQ logic in etl_seller_catalog.py
3. Run the spark-submit script to test
