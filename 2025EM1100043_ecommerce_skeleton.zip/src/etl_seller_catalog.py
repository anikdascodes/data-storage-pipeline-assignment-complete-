import sys
import argparse
import yaml
from pyspark.sql import SparkSession

def main(config_path):
    # 1. Load YAML config
    with open(config_path) as f:
        config = yaml.safe_load(f)
    input_path = config['seller_catalog']['input_path']
    output_path = config['seller_catalog']['hudi_output_path']

    # 2. Create SparkSession
    spark = SparkSession.builder.appName("ETL_SellerCatalog").getOrCreate()

    # 3. Read raw data (csv/tsv/other)
    df = spark.read.option("header", True).csv(input_path)
    print("Sample input rows:")
    df.show(5, truncate=False)

    # TODO: Add cleaning, DQ checks, quarantine handling, Hudi write

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True, help="Path to YAML config")
    args = parser.parse_args()
    main(args.config)
